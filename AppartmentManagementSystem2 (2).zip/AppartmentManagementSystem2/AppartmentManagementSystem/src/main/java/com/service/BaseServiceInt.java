package com.service;

public interface BaseServiceInt {

}
