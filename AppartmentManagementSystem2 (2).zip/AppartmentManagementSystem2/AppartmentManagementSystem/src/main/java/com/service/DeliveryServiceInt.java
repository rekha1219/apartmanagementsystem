package com.service;

public interface DeliveryServiceInt {

	
}
