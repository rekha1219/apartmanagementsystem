package com.service;

public interface UserServiceInt {

}
