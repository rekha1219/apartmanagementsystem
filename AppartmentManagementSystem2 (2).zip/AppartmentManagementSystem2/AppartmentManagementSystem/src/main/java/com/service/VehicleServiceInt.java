package com.service;

public interface VehicleServiceInt {

}
