package com.service;

public interface FlatRentServiceInt {

	
	
}
