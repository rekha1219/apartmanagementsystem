package com.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.entities.GardShiftEntity;



public interface GardShiftServiceInt {

}
