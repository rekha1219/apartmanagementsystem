package com.entities;

public interface DropdownList {
	public String getKey();

	public String getValue();

}
